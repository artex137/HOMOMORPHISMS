
function filterImages() {
    const searchTerm = document.getElementById('searchBar').value.toLowerCase();
    const imageCards = document.querySelectorAll('.image-card');

    imageCards.forEach(card => {
        const caption = card.getAttribute('data-caption').toLowerCase();
        if (caption.includes(searchTerm)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
